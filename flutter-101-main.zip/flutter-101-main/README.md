# flutter-101

First time learning flutter

## Current Progress: 

![image](https://github.com/user-attachments/assets/7bc0feb7-8da5-4e5a-9e1c-4c5af6f9c293)

